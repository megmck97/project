<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\JobController;

Route::get('/user/{uuid}', [ProfileController::class, 'index']);

Route::group(['middleware' => 'auth'], function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    Route::group(['prefix' => 'jobs'], function () {
        Route::get('/', [JobController::class, 'index'])->name('jobs');
        Route::get('/{uuid}', [JobController::class, 'show']);
    });


    Route::group(['prefix' => 'settings'], function () {
        Route::get('/account', [AccountController::class, 'index']);
        Route::post('/account', [AccountController::class, 'updateAccount']);

        Route::get('/password', fn () => view('account.password'));
        Route::post('/password', [AccountController::class, 'updatePassword']);
    });
});

require __DIR__ . '/auth.php';




// Route::group(['middleware' => 'auth'], function () {

//     Route::post('/tow', [TowController::class, 'store']);
//     Route::put('/tow/{uuid}', [TowController::class, 'update'])->name('tow.update');
//     Route::get('/history', [TowController::class, 'history'])->name('history');

//     Route::group(['prefix' => 'manage'], function () {

//         Route::group(['prefix' => 'business', 'namespace' => 'Teamwork'], function () {
//             Route::get('/', [App\Http\Controllers\Teamwork\TeamController::class, 'edit'])->name('teams.edit');
//             Route::put('/{id}', [App\Http\Controllers\Teamwork\TeamController::class, 'update'])->name('teams.update');
//         });

//         Route::get('/pricing', [App\Http\Controllers\Teamwork\TeamController::class, 'pricing'])->name('teams.pricing');

//         Route::group(['prefix' => 'employees', 'namespace' => 'Teamwork'], function () {
//             Route::get('/', [App\Http\Controllers\Teamwork\TeamMemberController::class, 'show'])->name('teams.members.show');
//             Route::get('/resend/{invite_id}', [App\Http\Controllers\Teamwork\TeamMemberController::class, 'resendInvite'])->name('teams.members.resend_invite');
//             Route::post('/{id}', [App\Http\Controllers\Teamwork\TeamMemberController::class, 'invite'])->name('teams.members.invite');
//             Route::delete('/{id}/{user_id}', [App\Http\Controllers\Teamwork\TeamMemberController::class, 'destroy'])->name('teams.members.destroy');
//         });

//         Route::get('/vehicles', [VehicleController::class, 'index']);
//         Route::post('/vehicles', [VehicleController::class, 'store']);
//         Route::delete('/vehicles/{id}', [VehicleController::class, 'delete']);

//         Route::get('/account', [AccountController::class, 'account']);
//         Route::post('/account', [AccountController::class, 'updateAccount']);
//         Route::get('/password', fn () => view('manage.password'));
//         Route::post('/password', [AccountController::class, 'updatePassword']);
//     });
// });
