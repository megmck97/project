<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="font-sans antialiased text-gray-900 bg-white">
    <?php echo e($slot); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\influencer-app-main\resources\views/layouts/guest.blade.php ENDPATH**/ ?>