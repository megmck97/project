<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if(View::hasSection('header')): ?>
            <header class="bg-white primary">
                <div class="px-4 py-4 mx-auto text-lg font-semibold text-gray-900 max-w-7xl sm:px-6">
                    <?php echo $__env->yieldContent('header'); ?>
                </div>
            </header>
            <?php endif; ?>

            <main class="w-full px-4 pt-10 mx-auto max-w-7xl sm:px-6">
                <?php echo e($slot); ?>

            </main>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\influencer-app-main\resources\views/layouts/app.blade.php ENDPATH**/ ?>