<aside class="w-[340px] px-4 md:px-8 md:pl-0">
	<div class="px-2">
		<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.avatar','data' => ['user' => $user,'class' => 'block w-20 h-20 rounded-full']]); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user),'class' => 'block w-20 h-20 rounded-full']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
		<h1 class="pt-6 pb-4 text-4xl font-medium tracking-tight"><?php echo e($user->name); ?></h1>
		<?php if(Auth::user()->id == $user->id): ?>
			<a href="/settings/account" class="px-5 py-2.5 text-sm inline-flex items-center space-x-2 font-extrabold text-white rounded-md bg-gray-500 trans hover:bg-gray-700">
				<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z"></path><path fill-rule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clip-rule="evenodd"></path></svg>
				<span class="">Edit Account</span>
			</a>
		<?php else: ?>
			<a href="mailto:<?php echo e($user->email); ?>" class="px-5 py-2.5 text-sm font-bold text-white rounded-md bg-primary-600 trans hover:bg-primary-700">Contact <?php echo e($user->name); ?></a>
		<?php endif; ?>
		
		<p class="py-8 text-base text-gray-700"><?php echo e($user->bio); ?></p>
		<?php if($user->type == 'influencer'): ?>
		<ul class="border border-gray-200 divide-y divide-gray-200 rounded-md">
			<li class="flex items-center justify-between px-4 py-3">
				<div>Gender:</div>
				<div class="capitalize"><?php echo e($user->gender); ?></div>
			</li>
			<li class="flex items-center justify-between px-4 py-3">
				<div>Follower Count:</div>
				<div class="capitalize"><?php echo e($user->follower_count); ?></div>
			</li>
			<li class="flex items-center justify-between px-4 py-3">
				<div>Age:</div>
				<div class="capitalize"><?php echo e($user->age); ?></div>
			</li>
			<li class="flex items-center justify-between px-4 py-3">
				<div>Industry:</div>
				<div class="capitalize"><?php echo e($user->industry); ?></div>
			</li>
			<li class="flex items-center justify-between px-4 py-3">
				<div>City:</div>
				<div class="capitalize"><?php echo e($user->city); ?></div>
			</li>
		</ul>
		<?php endif; ?>
	</div>

	</nav>
</aside><?php /**PATH C:\xampp\htdocs\influencer-app-main\resources\views/profile/_sidebar.blade.php ENDPATH**/ ?>