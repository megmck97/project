<?php $attributes = $attributes->exceptProps([
'user',
'size',
'rounded',
'shadow',
'border',
'client'
]); ?>
<?php foreach (array_filter(([
'user',
'size',
'rounded',
'shadow',
'border',
'client'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php

$name = $user->name;
$name_array = explode(' ',trim($name));

$firstWord = $name_array[0];
$lastWord = $name_array[count($name_array)-1];

if($firstWord == $lastWord){
	$initials = $firstWord[0];
	
} else {
	$initials = $firstWord[0]."".$lastWord[0];
}

$number = preg_replace("/[^0-9]/", "", $user->id );

if($number > 9) {
$number = substr($number, 0, 1);
};

$number = (float)$number;

$colors = [
"bg-blue-500",
"bg-red-500",
"bg-yellow-500",
"bg-green-500",
"bg-teal-500",
"bg-blue-500",
"bg-primary-500",
"bg-purple-500",
"bg-pink-500",
"bg-red-500",
];

$bg = $colors[$number];

$path = 'avatars';

$sds = 'h-12 w-12';

?>

<?php if(isset($user->avatar)): ?>
<img src="/storage/<?php echo e($path); ?>/<?php echo e($user->avatar); ?>" alt="<?php echo e($user->name); ?>"
	class="<?php if(isset($shadow)): ?> primary <?php endif; ?>
	<?php if(isset($rounded)): ?> rounded-full <?php else: ?> rounded-md <?php endif; ?>
	<?php if(isset($size)): ?> w-<?php echo e($size); ?> h-<?php echo e($size); ?> <?php else: ?> w-14 h-14 <?php endif; ?> object-cover bg-white flex-shrink-0">
<?php else: ?>
<div
	class="
	<?php if(isset($shadow)): ?> primary <?php endif; ?> inline-flex items-center justify-center font-semibold text-white <?php echo e($bg); ?>

	<?php if(isset($rounded)): ?> rounded-full <?php else: ?> rounded-md <?php endif; ?>
	<?php if(isset($size)): ?> <?php if($size <= 10): ?> text-sm <?php elseif($size >= 24): ?> text-4xl tracking-widest <?php else: ?> text-lg tracking-widest <?php endif; ?> w-<?php echo e($size); ?> h-<?php echo e($size); ?> <?php else: ?> w-14 h-14 <?php endif; ?> flex-shrink-0">
	<?php echo e($initials); ?>

</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\influencer-app-main\resources\views/components/avatar.blade.php ENDPATH**/ ?>