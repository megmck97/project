<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <form action="<?php echo e(url('/settings/password')); ?>" id="password" method="POST"
        class="flex-1 w-full p-6 space-y-6 overflow-hidden bg-white border border-gray-200 sm:rounded-lg">

        <h3 class="text-xl font-medium leading-6 text-gray-900">Password</h3>

        <div class="space-y-2">
            <label for="current_password" class="block text-sm font-medium leading-5 text-gray-700">
                Current Password
            </label>
            <input id="current_password" type="password" name="current_password"
                class="block w-full px-3 py-2 transition duration-150 ease-in-out border border-gray-300 rounded-md shadow-sm form-input focus:outline-none focus:shadow-outline-blue focus:border-blue-300 sm:text-sm sm:leading-5 <?php echo e($errors->has('current_password') ? 'border-red-500': ''); ?>">
            <?php echo $errors->first('current_password', '<div class="mt-1 text-xs italic text-red-500">
                :message</div>'); ?>

        </div>

        <div class="space-y-2">
            <label for="password" class="block text-sm font-medium leading-5 text-gray-700">
                New Password
            </label>
            <input id="password" type="password" name="password" required
                class="block w-full px-3 py-2 transition duration-150 ease-in-out border border-gray-300 rounded-md shadow-sm form-input focus:outline-none focus:shadow-outline-blue focus:border-blue-300 sm:text-sm sm:leading-5 <?php echo e($errors->has('password') ? 'border-red-500': ''); ?>">
            <?php echo $errors->first('password', '<div class="mt-1 text-xs italic text-red-500">
                :message</div>'); ?>

        </div>

        <div class="space-y-2">
            <label for="password_confirmation" class="block text-sm font-medium leading-5 text-gray-700">
                Confirm Password
            </label>
            <input id="password_confirmation" type="password" name="password_confirmation"
                class="block w-full px-3 py-2 transition duration-150 ease-in-out border border-gray-300 rounded-md shadow-sm form-input focus:outline-none focus:shadow-outline-blue focus:border-blue-300 sm:text-sm sm:leading-5 <?php echo e($errors->has('password_confirmation') ? 'border-red-500': ''); ?>">
            <?php echo $errors->first('password_confirmation', '<div class="mt-1 text-xs italic text-red-500">
                :message</div>
            '); ?>

        </div>

        <div class="flex justify-end">
            <button type="submit"
                class="inline-flex items-center justify-center px-4 py-2 ml-3 space-x-2 text-sm font-semibold text-white transition duration-200 ease-in-out border border-transparent rounded-md shadow-sm bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                <span>Save</span>
            </button>
        </div>
        <?php echo csrf_field(); ?>
    </form>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\influencer-app-main\resources\views/account/password.blade.php ENDPATH**/ ?>