<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo e(config('app.name', 'Tawo')); ?></title>

<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script><?php /**PATH C:\xampp\htdocs\influencer-app-main\resources\views/partials/head.blade.php ENDPATH**/ ?>