<?php

namespace App\Services;

use Illuminate\Support\Str;

class UuidGenerator
{

    /**
     * Generate uid for models
     */
    public function generate($model, $count = 8, $field = 'uuid')
    {
        return $this->uuid($model, $count, $field);
    }

    /**
     * Generate uid
     * 
     * @param object $model
     * @return string
     */
    private function uuid($model, $count, $field)
    {
        $uuid = Str::random($count);
        $hasUuid = $model->where($field, $uuid)
            ->count();

        while ($hasUuid == 0) {
            return $uuid;
        }
    }
}
