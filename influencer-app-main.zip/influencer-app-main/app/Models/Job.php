<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Services\UuidGenerator;


class Job extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'title',
        'description',
        'uuid',
        'brand',
    ];

    protected static function booted()
    {
        self::creating(function ($model) {
            $uuid = app(UuidGenerator::class)->generate($model, 10);
            $model->uuid = strtoupper($uuid);
        });
    }

    public function owner()
    {
        return $this->belongsTo('App\Models\User', 'brand', 'id');
    }

}
