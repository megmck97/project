<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

use Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        

        if ($user) {
            if($user->type == 'influencer') {
                $results = User::where('type', 'brand')->get();
                return view('dashboard.index')->with('user', $user)->with('results', $results);
            } elseif($user->type == 'brand') {
                $results = User::where('type', 'influencer')->get();
                return view('dashboard.index')->with('user', $user)->with('results', $results);
            }
            
        } else {
            return abort(404);
        };
    }
}



// class ProfileController extends Controller
// {
//     public function index($username)
//     {
//         

//         if ($user) {
//             return view('profile.index')->with('user', $user);
//         } else {
//             return abort(404);
//         };
//     }
// }
