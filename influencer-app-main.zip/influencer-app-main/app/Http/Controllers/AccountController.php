<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests\AccountRequest;
use App\Http\Requests\PasswordRequest;

use Auth;

use Image;
use Storage;

class AccountController extends Controller
{

    public function index()
    {

        $user = auth()->user();
        return view('account.index')->with('user', $user);
    }


    /**
     * Show account page
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Http\Requests\AccountRequest $accountRequest
     * @return \Illuminate\Http\Response
     */
    public function updateAccount(Request $request, AccountRequest $accountRequest)
    {
        $user = auth()->user();
        $user->fill($request->all());
        $this->updateavatar($user);
        $user->save();

        return redirect()
            ->back()
            ->with('success', 'Profile successfully updated!');
    }

    /**
     * Show account page
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Http\Requests\AccountRequest $accountRequest
     * @return \Illuminate\Http\Response
     */
    public function updatePassword(Request $request, PasswordRequest $passwordRequest)
    {
        $user = auth()->user();
        $user->password = bcrypt($request['password']);
        $user->save();

        return redirect()
            ->back()
            ->with('success', 'Password successfully updated!');
    }

    /**
     * Update user avatar
     * 
     * @param  \App\User
     * @return void
     */
    public function updateavatar(&$user)
    {
        $avatar = request()->avatar;
        if (!$avatar) {
            return;
        }

        $name = date('mdYHis') . uniqid();
        $ext = $avatar->getClientOriginalExtension();
        $path = storage_path('app/public/avatars');
        $fileName = $name . '.' . $ext;

        // Store image to storage
        $avatar->storeAs('public/avatars', $fileName);

        // Create a thumbnail
        $img = Image::make($avatar->getRealPath())
            ->resize(400, 400, function ($constraint) {
                $constraint->aspectRatio();
            });

        $img->save($path . '/' . $fileName);

        Storage::delete(['public/avatars/' . $user->avatar]);

        $user->avatar = $fileName;
    }
}
