<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Job;

class ProfileController extends Controller
{
    public function index($uuid)
    {
        $user = User::where('uuid', $uuid)->first();
        $results = Job::where('brand', $user->id)->get();

        if ($user) {
            return view('profile.index')->with('user', $user)->with('results', $results);
        } else {
            return abort(404);
        };
    }
}
