<x-app-layout>

	@section('header')
			Jobs
	@endsection

	@if($results && $results->count() != 0)

		@if($user->type == 'influencer')
		<div class="pb-12 space-y-8">
		@foreach($results as $result)
			<div class="overflow-hidden bg-white shadow sm:rounded-lg">
				<div class="flex items-center w-full px-4 py-5 sm:px-6">
					<h3 class="text-lg font-medium leading-6 text-gray-900">
						{{ $result->title }}
					</h3>
					<div class="flex justify-end flex-1">
						<a href="mailto:{{ $result->owner->email }}" class="inline-flex items-center px-4 py-2 text-sm font-medium text-white border border-transparent rounded-md shadow-sm bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
							<svg class="w-5 h-5 mr-2 -ml-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
								<path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
								<path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
							</svg>
							Contact
						</a>
					</div>
				</div>
				<div class="border-t border-gray-200">
					<dl>
						<div class="px-4 py-5 bg-gray-50 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
							<dt class="text-sm font-medium text-gray-500">
								Brand
							</dt>
							<dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
								<a href="/user/{{ $result->owner->uuid }}" class="flex items-center space-x-2 ">
									<x-avatar :user="$result->owner" rounded :size="8" />
									<div class="font-semibold text-gray-800 underline">{{ $result->owner->name }}</div>
								</a>
							</dd>
						</div>
						<div class="px-4 py-5 bg-white sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
							<dt class="text-sm font-medium text-gray-500">
								Job Posted
							</dt>
							<dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
								{{ $result->created_at->diffForHumans() }}
							</dd>
						</div>
						<div class="px-4 py-5 bg-gray-50 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
							<dt class="text-sm font-medium text-gray-500">
								Contact Email address
							</dt>
							<dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
								{{ $result->owner->email }}
							</dd>
						</div>
						<div class="px-4 py-5 bg-gray-50 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
							<dt class="text-sm font-medium text-gray-500">
								Description
							</dt>
							<dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
								{{ $result->description }}
							</dd>
						</div>
					</dl>
				</div>
			</div>
			@endforeach
			</div>

		@else
			<div class="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
			@foreach($results as $result)
					<a href="/jobs/{{ $result->uuid }}" class="p-3 bg-white rounded primary">
							<div class="flex items-center space-x-4">
									<x-avatar :user="$result->owner" rounded :size="12" />
									<div>
										<div class="text-base font-semibold text-gray-900">{{ $result->title }}</div>
										<div class="text-sm font-medium text-gray-500">{{ $result->owner->name }}</div>
									</div>
							</div>
					</a>
			@endforeach
			</div>
		@endif
	@else
			<div class="relative block w-full p-12 text-center border-2 border-gray-300 border-dashed rounded-lgtrans">
					<svg class="w-10 h-10 mx-auto text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path></svg>
					<span class="block mt-2 font-semibold text-gray-900">
							Nothing found.
					</span>
			</div>
	@endif
	
</x-app-layout>