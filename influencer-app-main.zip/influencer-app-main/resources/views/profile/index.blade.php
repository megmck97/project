<x-app-layout>
	<div class="w-full app-bg">
		<div class="flex w-full min-h-[700px] px-6 mx-auto max-w-7xl">
			
			@include('profile._sidebar')

			<main class="flex-1 px-10 pb-12 bg-gray-100">
				
				@if($user->type == 'influencer1')
					<iframe class="w-full h-[800px]" src="https://www.instagram.com/p/CXOg1AHj_Vo/embed"></iframe>
				@else
					<div class="flex flex-col space-y-6">
						@forelse($results as $result)
						<div class="overflow-hidden bg-white shadow sm:rounded-lg">
							<div class="flex items-center w-full px-4 py-5 sm:px-6">
								<h3 class="text-lg font-medium leading-6 text-gray-900">
									{{ $result->title }}
								</h3>
								<div class="flex justify-end flex-1">
									<a href="mailto:{{ $result->owner->email }}" class="inline-flex items-center px-4 py-2 text-sm font-medium text-white border border-transparent rounded-md shadow-sm bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
										<svg class="w-5 h-5 mr-2 -ml-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
											<path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
											<path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
										</svg>
										Contact
									</a>
								</div>
							</div>
							
							@if($user->type == 'influencer')
							<div class="border-t border-gray-200">
								<dl>
									<div class="px-4 py-5 bg-gray-50 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
										<dt class="text-sm font-medium text-gray-500">
											Brand
										</dt>
										<dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
											{{ $result->owner->name }}
										</dd>
									</div>
									<div class="px-4 py-5 bg-white sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
										<dt class="text-sm font-medium text-gray-500">
											Job Posted
										</dt>
										<dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
											{{ $result->created_at->diffForHumans() }}
										</dd>
									</div>
									<div class="px-4 py-5 bg-gray-50 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
										<dt class="text-sm font-medium text-gray-500">
											Contact Email address
										</dt>
										<dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
											{{ $result->owner->email }}
										</dd>
									</div>
									<div class="px-4 py-5 bg-gray-50 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
										<dt class="text-sm font-medium text-gray-500">
											Description
										</dt>
										<dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
											{{ $result->description }}
										</dd>
									</div>
								</dl>
							</div>
							@endif

						</div>
						@empty
							No jobs
						@endforelse
					</div>
				@endif
			</main>

		</div>
	</div>
</x-app-layout>