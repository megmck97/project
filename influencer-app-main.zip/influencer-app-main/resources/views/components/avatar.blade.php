@props([
'user',
'size',
'rounded',
'shadow',
'border',
'client'
])

@php

$name = $user->name;
$name_array = explode(' ',trim($name));

$firstWord = $name_array[0];
$lastWord = $name_array[count($name_array)-1];

if($firstWord == $lastWord){
	$initials = $firstWord[0];
	
} else {
	$initials = $firstWord[0]."".$lastWord[0];
}

$number = preg_replace("/[^0-9]/", "", $user->id );

if($number > 9) {
$number = substr($number, 0, 1);
};

$number = (float)$number;

$colors = [
"bg-blue-500",
"bg-red-500",
"bg-yellow-500",
"bg-green-500",
"bg-teal-500",
"bg-blue-500",
"bg-primary-500",
"bg-purple-500",
"bg-pink-500",
"bg-red-500",
];

$bg = $colors[$number];

$path = 'avatars';

$sds = 'h-12 w-12';

@endphp

@if (isset($user->avatar))
<img src="/storage/{{ $path }}/{{ $user->avatar }}" alt="{{ $user->name }}"
	class="@if(isset($shadow)) primary @endif
	@if(isset($rounded)) rounded-full @else rounded-md @endif
	@if(isset($size)) w-{{ $size }} h-{{ $size }} @else w-14 h-14 @endif object-cover bg-white flex-shrink-0">
@else
<div
	class="
	@if(isset($shadow)) primary @endif inline-flex items-center justify-center font-semibold text-white {{ $bg }}
	@if(isset($rounded)) rounded-full @else rounded-md @endif
	@if(isset($size)) @if($size <= 10) text-sm @elseif($size >= 24) text-4xl tracking-widest @else text-lg tracking-widest @endif w-{{ $size }} h-{{ $size }} @else w-14 h-14 @endif flex-shrink-0">
	{{ $initials }}
</div>
@endif