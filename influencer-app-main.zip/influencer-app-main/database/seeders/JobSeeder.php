<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Job;

class JobSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Job::create([
            'title' => 'Nike Air Max Campaign',
            'brand' => 2,
            'description' => 'We need an influencer to run a giveaway competition for a new set of Nike Air Max Trainers.',
        ]);
        Job::create([
            'title' => 'Nike Summer Campaign',
            'brand' => 2,
            'description' => 'Our summer launch requires a four week promotional campaign, includes content photoshoot and launch party event.',
        ]);
        Job::create([
            'title' => 'Just Do It - UK',
            'brand' => 2,
            'description' => 'Our campaign is tailored specifically for fitness fanatics. Influencer needed for 2 month ongoing campaign, affiliate marketing opportunity with discount code to improve online sales.',
        ]);
        Job::create([
            'title' => 'Challenge Yourself - ROI',
            'brand' => 2,
            'description' => 'We are scouting a full time influencer to be the face of our campaign. This will involve paid photoshoot trips to Dublin, Manchester and London, all accommodation costs covered. We expect in return a weekly promotional video on Facebook and Instagram to promote our new stock.',
        ]);
        Job::create([
            'title' => 'Christmas 2022',
            'brand' => 2,
            'description' => 'Christmas 2022 will involve a Christmas themed giveawy competition',
        ]);
    }
}
