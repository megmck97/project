<?php

namespace Database\Seeders;

use DB;

use Illuminate\Database\Seeder;
use App\Models\User;

class TestUsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'Megan',
            'email' => 'megan@gmail.com',
            'bio' => 'Sed posuere consectetur est at lobortis. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla vitae elit libero, a pharetra augue.',
            'password' => bcrypt('1'),
            'gender' => 'female',
            'follower_count' => '340',
            'age' => '22',
            'industry' => 'beauty',
            'city' => 'belfast',
            'instagram' => 'megmckinstry',

        ]);

        User::create([
            'name' => 'Nike',
            'email' => 'nike@nike.com',
            'type' => 'brand',
            'bio' => 'Nike, Inc. is an American multinational corporation that is engaged in the design, development, manufacturing, and worldwide marketing and sales of footwear, apparel, equipment, accessories, and services.',
            'password' => bcrypt('1'),
        ]);
    }
}
