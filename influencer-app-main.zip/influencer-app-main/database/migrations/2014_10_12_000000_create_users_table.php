<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Services\UuidGenerator;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('uuid')->nullable();
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('avatar')->nullable();
            $table->string('type')->default('influencer');
            $table->longText('bio')->nullable();
            $table->string('gender')->nullable();
            $table->string('follower_count')->nullable();
            $table->string('age')->nullable();
            $table->string('industry')->nullable();
            $table->string('city')->nullable();
            $table->string('instagram')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    protected static function booted()
    {
        self::creating(function ($model) {
            $uuid = app(UuidGenerator::class)->generate($model, 10);
            $model->uuid = strtoupper($uuid);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
    
}
